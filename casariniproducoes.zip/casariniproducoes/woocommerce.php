<?php get_header(); ?>

  
    <div class="woocommerce container">

      <div class="row">

        <div class="col-12">
        <?php woocommerce_content();?>
</div>

      </div><!-- .row -->
    </div><!-- .container -->


<?php get_footer(); ?>