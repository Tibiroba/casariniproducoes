<section class="container-fluid footer-container">
    <div class="row p-20">
        
    </div>
    </div>
        </section>
        <section class="footer-container2">
            <div class="container-fluid">
                <div class="row">

                
        <div class="col-12 col-sm-3">
        <h3 class="footer-title">Atendimento</h3>
        <ul class="footer-lista">
                <li><a target="_blank" href="https://">Conta</a></li>
                <li><a target="_blank" href="https://">Carrinho</a></li>
                <li><a target="_blank" href="https://">Pedidos</a></li>
               
            </ul>
            <ul class="footer-lista">
                <li><a target="_blank" href="https://">Nossa História</a></li>
                <li><a target="_blank" href="https://">Política de Trocas e Devoluções</a></li>
                <li><a target="_blank" href="https://">Política de Entregas</a></li>
                <li><a target="_blank" href="https://">Garantia</a></li>
            </ul>

          
        </div>
        <div class="col-12 col-sm-3">
            <h3 class="footer-title">Fale conosco</h3>
            <ul class="footer-lista">
                <li><a target="_blank" href="">contato@soldierpratas.com</a></li>
                <li><a target="_blank" href="">(11) 4039-1477</a></li>
                <li><a target="_blank" href="https://contato">Atendimento de Segunda a Sábado das 9h às 18h.</a></li>
            </ul>
        
        </div>
        <div class="col-12 col-sm-3">
        <h3 class="footer-title">Pagamento</h3>
        <ul class="footer-pagtos" style="display:inline-flex;">
                <li><img alt="img.jpg" src="<?php echo get_stylesheet_directory_uri()?>/img/deposito.webp" alt="deposito"></li>
                <li><img alt="img.jpg" src="<?php echo get_stylesheet_directory_uri()?>/img/boleto.webp" alt="boleto"></li>
                <li><img alt="img.jpg" src="<?php echo get_stylesheet_directory_uri()?>/img/visa.webp" alt="cartao-dinners"></li>
                <li><img alt="img.jpg" src="<?php echo get_stylesheet_directory_uri()?>/img/mastercard.webp" alt="cartao-dinners"></li>
                <li><img alt="img.jpg" src="<?php echo get_stylesheet_directory_uri()?>/img/bradesco.webp" alt="bancobradesco"></li>
              
            </ul>
            
            <h3 class="footer-title">Compra Segura</h3>
           <ul class="footer-pagtos">
               <li><img alt="img.jpg" src="<?php echo get_stylesheet_directory_uri()?>/img/ssl.png" alt="ssl"></li>
               <li><img alt="img.jpg" src="<?php echo get_stylesheet_directory_uri()?>/img/google.webp" alt="Google Safe"></li>
           </ul>

        </div>
        <div class="col-12 col-sm-3">
            <h3 class="footer-title">Redes Sociais</h3>
            <ul class="footer-lista" style="display:inline-flex;justify-content: space-around;">
                <li><a target="_blank" href="https://api.whatsapp.com/send?phone=551140391477&text=Trevisan%20Alian%C3%A7as%20-%20Seu%20sonho%20come%C3%A7a%20aqui."><img alt="img.jpg" src="<?php echo get_stylesheet_directory_uri();?>/img/whatsapp.png"></a></li>
                <li><a target="_blank" href="https://www.instagram.com/trevisanaliancas/"><img alt="img.jpg" src="<?php echo get_stylesheet_directory_uri();?>/img/instagram.png"></a></li>
                <li><a target="_blank" href="http://facebook.com/trevisanaliancas"><img alt="img.jpg" src="<?php echo get_stylesheet_directory_uri();?>/img/facebook.png"></a></li>
                <li><a target="_blank" href="http://youtube.com/trevisanaliancas"><img alt="img.jpg" src="<?php echo get_stylesheet_directory_uri();?>/img/youtube.png"></a></li>
            </ul>
            </div>
        </div>
        
    </div>
    </div>
            </div>
</section>

<?php wp_footer(); ?>
</body>
</html>